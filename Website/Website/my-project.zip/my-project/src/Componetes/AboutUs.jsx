import React from 'react'
// import Footer from './Footer'
const AboutUs = () => {
  return (
    <div>
        <div className='bg-image '>
          <div className='flex justify-center items-center p-[150px] text-white font-semibold text-5xl'>About US</div>
        </div>
        <div className='grid grid-cols-2 '>
            <img className='h-[300px] m-14 ' src="https://depot.qodeinteractive.com/wp-content/uploads/2017/01/about-img-1.jpg" alt="" />
            <div className='space-x-6 mt-10 '>
              <button className='border  border-black  py-4 px-6 bg-black text-white  '>About Us</button>
              <button className='border  border-black py-4 px-6  hover:bg-black hover:text-white'>Services</button>
              <button className='border  border-black py-4 px-6 hover:bg-black hover:text-white'>History</button>
              <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto facilis asperiores ipsum nulla illum error? Neque asperiores amet modi est, temporibus excepturi, facere provident id fugiat ex enim at omnis?</p>
            </div>
        </div>
       
    </div>
  )
}

export default AboutUs