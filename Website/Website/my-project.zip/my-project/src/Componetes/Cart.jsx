import React from 'react'

const Cart = () => {
  return (
    <div>
        <div className='bg-img2'>
            <div className='flex justify-center items-center h-[300px] text-5xl text-white font-semibold'>CART</div>
        </div>
    </div>
  )
}

export default Cart