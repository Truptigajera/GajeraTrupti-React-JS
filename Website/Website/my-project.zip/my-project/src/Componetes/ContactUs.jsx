import React from 'react'

const ContactUs = () => {
  return (
    <div>
        <h1>Thuis is Contact page</h1>
    </div>
  )
}

export default ContactUs